import * as Yup from 'yup';

export function initialValue(Activo) {
  return {
    File:''
  };
}

export function validationSchema(initialValues) {
  return Yup.object({
 });
}
