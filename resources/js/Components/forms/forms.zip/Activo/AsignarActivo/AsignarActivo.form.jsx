import * as Yup from 'yup';

export function initialValue(Activo) { 
  return {
    taqActivos  : "",
  };
}

export function validationSchema(initialValues) {
  return Yup.object({
    
 });
}
